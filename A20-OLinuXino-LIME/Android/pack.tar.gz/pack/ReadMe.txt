1. Navigate to lichee/tools/pack/chips/sun7i/configs/android/
2. Extract olinuxino-a20.tgz
